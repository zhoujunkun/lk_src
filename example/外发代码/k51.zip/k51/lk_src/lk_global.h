#ifndef __LK_GLOBAL_H
#define __LK_GLOBAL_H

#include "stdint.h"
#include "stdio.h"
#include "stdbool.h"





#endif


